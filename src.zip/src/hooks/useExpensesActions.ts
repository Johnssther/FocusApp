import { Expense, deleteExpenseById, storeExpense } from '../redux/expenses/slice';
import { useAppDispatch, useAppSelector } from './store';

export const useExpensesActions = () => {
  const dispatch = useAppDispatch();

  /* Store Expense  */
  const storeHandleExpense = async (expense: Expense) => {    
    await dispatch( storeExpense(expense) )
  };

  /* Update Expense  */
  const updateExpense = async (id:number) => {
    // pass...
  };

  /* Delete Expense  */
  const removeExpense = async (id:number) => {
    await dispatch( deleteExpenseById(id) )
  };
  
  return { storeHandleExpense, updateExpense, removeExpense }
}
