import React, { useState } from 'react';
import { View, Text, TouchableOpacity, StyleSheet, Alert, Image } from 'react-native';
import TextInput from '../components/TextInput/TextInput';

import { useSelector } from 'react-redux';

const LoginScreen = ({navigation}) => {
  const [ username, setUsername ] = useState('');
  const [ password, setPassword ] = useState('');
  const [ secureTextEntry, setSecureTextEntry ] = useState(true);
  
  const userAuth = useSelector((state) => state.userAuth);

  const onLogin = () => {
    navigation.navigate('Home')
  }

  return (
    <>
    <View style={styles.containerMain}>
      <View style={styles.containerLogo}>
      <Image
        source={{ uri: 'https://www.creativefabrica.com/wp-content/uploads/2020/02/10/Money-Logo-Graphics-1-4.jpg' }}
        style={styles.image}
      />
        <Text style={styles.title}>Login</Text>
      </View>
      <View style={styles.container}>
        <TextInput
          placeholder='Correo electrónico'
          keyboardType='email-address'
          autoCapitalize='none'
          value={username}
          onChange={(username) => setUsername(username)}
        />

        <TextInput
          placeholder='Contraseña'
          secureTextEntry={secureTextEntry}
          value={password}
          onChange={(password) => setPassword(password)}
        />
        {/* <TouchableOpacity style={styles.forgotPasswordContainer} onPress={() => setSecureTextEntry(!secureTextEntry)}>
          <Text style={styles.forgotPasswordText}>Ver contraseña</Text>
        </TouchableOpacity> */}

        <TouchableOpacity style={styles.loginButton} onPress={() => onLogin() }>
          <Text style={styles.loginButtonText}>Login</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.forgotPasswordContainer}>
          <Text style={styles.forgotPasswordText}>Or login with</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.loginButtonGoogle}>
          <Text style={styles.loginButtonGoogleText}>Google</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.loginButtonGoogle}>
          <Text style={styles.loginButtonGoogleText}>Facebook</Text>
        </TouchableOpacity>

        <TouchableOpacity style={styles.forgotPasswordContainer}>
          <Text style={styles.forgotPasswordText}>Forgot password?</Text>
        </TouchableOpacity>
      </View>
    </View>
    </>
  );
};

const styles = StyleSheet.create({
  containerMain: {
    flex: 1,
    backgroundColor: 'white',
  },
  image: {
    width: 128, // Ancho deseado de la imagen
    height: 128, // Altura deseada de la imagen
    borderRadius: 100, // Para redondear la imagen (la mitad del ancho o altura)
  },
  containerLogo: {
    height: 260,
    justifyContent: 'center',
    alignItems: 'center',
    
  },
  container: {
    flex: 1,
    justifyContent: 'start',
    alignItems: 'center',
    padding: 20,
    backgroundColor:'#ffffff',
  },
  title: {
    fontSize: 39,
    fontWeight: 'bold',
    marginBottom: 20,
    color: 'black',
    textAlign: 'center',
  },
  input: {
    width: '100%',
    height: 40,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 20,
    padding: 10,
  },
  loginButton: {
    backgroundColor: '#36b436',
    padding: 10,
    borderRadius: 35,
    width: '100%',
    height: 50,
    marginTop: 12,
    justifyContent: 'center', // Centrado vertical
    alignItems: 'center', // Centrado horizontal
  },
  loginButtonText: {
    color: 'white',
    textAlign: 'center',
    fontWeight: 'bold',
  },
  loginButtonGoogle: {
    padding: 10,
    borderRadius: 35,
    width: '100%',
    height: 50,
    marginTop: 12,
    justifyContent: 'center', // Centrado vertical
    alignItems: 'center', // Centrado horizontal
    borderWidth: 1,
    borderColor: '#bcabab',
  },
  loginButtonGoogleText: {
    color: '#3b82f6',
    textAlign: 'center',
    fontWeight: 'bold',
  },
  forgotPasswordContainer: {
    marginTop: 10,
  },
  forgotPasswordText: {
    color: '#8d7f7f',
  },
});

export default LoginScreen;
