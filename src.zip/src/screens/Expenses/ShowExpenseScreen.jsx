import React from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { useAppSelector } from '../../hooks/store';
import { gray } from '../../config/colors';
import { useRoute } from '@react-navigation/native';

import { useExpensesActions } from '../../hooks/useExpensesActions'

const ShowExpenseScreen = ({navigation}) => {
  const { removeExpense } = useExpensesActions()

  const route = useRoute();
  const { expenseId } = route.params;

  const expenses = useAppSelector((state) => state.expenses);
  const expenseItem = expenses.find((expense) => expense.id === expenseId);
  const { id, name, justification, quantity, unitPrice, totalPrice } = expenseItem;

  const handleAddExpense = async () => {
    navigation.navigate('CreateExpenseScreen')
  }

  const handleRemoveExpense = async (id) => {
    navigation.navigate('IndexExpensesScreen')
    removeExpense(id)
  }

  if (!expenseItem) {
    // Si no se encontró ningún gasto con el ID proporcionado
    return (
      <View style={styles.container}>
        <Text>No se encontró ningún gasto con el ID proporcionado.</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.item}>
        <Text style={styles.name}>Nombre del gasto:</Text>
        <Text style={styles.title}>{ name }</Text>
      </View>
      <View style={styles.item}>
        <Text style={styles.name}>Cantidad:</Text>
        <Text style={styles.value}>{ quantity }</Text>
      </View>
      <View style={styles.item}>
        <Text style={styles.name}>Justification:</Text>
        <Text style={styles.value}>{ justification } </Text>
      </View>
      <View style={styles.item}>
        <Text style={styles.name}>Precio unidad:</Text>
        <Text style={styles.value}>{ unitPrice }</Text>
      </View>
      <View style={styles.item}>
        <Text style={styles.name}>Precio total:</Text>
        <Text style={styles.value}>{ totalPrice } ({unitPrice*quantity})</Text>
      </View>
      <View style={styles.item}>
        <Text style={styles.name}>ID: {id}</Text>
        <Text style={styles.value}>{ id }</Text>
      </View>
      <TouchableOpacity style={styles.loginButton} onPress={() => handleAddExpense() }>
        <Text style={styles.loginButtonText}>Agregar nuevo gasto</Text>
      </TouchableOpacity>
      <TouchableOpacity style={styles.deleteButton} onPress={() => handleRemoveExpense(id) }>
        <Text style={styles.loginButtonText}>Eliminar</Text>
      </TouchableOpacity>
    </View>
  );
  
};

const styles = StyleSheet.create({
  item: {
    flexDirection: 'col',
    justifyContent: 'center',
    alignItems: 'center',
    gap: 7,
    width: 400,
    height: 'auto',
  },
  name: {
    fontWeight:"bold",
    fontSize: 18,
  },
  title: {
    fontWeight:"bold",
    fontSize: 32,
    marginBottom:12,
  },
  value: {
    fontWeight:"normal",
    fontSize: 18,
  },
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    padding: 20,
    backgroundColor:'#f1f5f9',
  },
  flag: {
    backgroundColor: 'white',
    padding:5,
    width: '100%',
    marginBottom: 5,
    borderRadius: 14,
    height: 70,
    justifyContent: 'center',
    paddingLeft: 9,
  },
  containerExpense: {
    display: 'flex',
    flexDirection: 'row',
  },
  expense: {
    color: '#4b5563',
    fontSize: 18,
    fontWeight: 'bold',
    width:'70%',
  },
  price: {
    color: gray[700],
    fontSize: 18,
    fontWeight: 'bold',
    width:'30%',
    textAlign: 'right',
  },
  date: {

  },
  loginButton: {
    backgroundColor: '#728242',
    padding: 10,
    borderRadius: 5,
    width: '100%',
    height: 50,
    marginTop: 12,
    justifyContent: 'center', // Centrado vertical
    alignItems: 'center', // Centrado horizontal
  },
  loginButtonText: {
    color: 'white',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 18,
  },
  deleteButton: {
    backgroundColor: '#a52b2b',
    padding: 10,
    borderRadius: 5,
    width: '100%',
    height: 50,
    marginTop: 12,
    justifyContent: 'center', // Centrado vertical
    alignItems: 'center', // Centrado horizontal
    marginTop: 18,
  },
});

export default ShowExpenseScreen;
