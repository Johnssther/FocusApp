import React, { useState } from 'react';
import { View, Text, StyleSheet, FlatList, TouchableOpacity } from 'react-native';
import { useSelector } from 'react-redux';
import { slate, gray } from '../../config/colors';
import TextInput from '../../components/TextInput/TextInput';
import { useExpensesActions } from '../../hooks/useExpensesActions'
import { useAppSelector } from '../../hooks/store';

const CreateExpenseScreen = ({navigation}) => {
  const [ quantity, setCount ] = useState(1);
  const [ name, setName ] = useState('');
  const [ unitPrice, setUnitPrice ] = useState(0);
  const [ totalPrice, setTotalPrice ] = useState(0);
  const [ justification, setJustification ] = useState('');

  const { storeHandleExpense } = useExpensesActions()
  const expenses = useAppSelector((state) => state.expenses )

  const onRegister = () => {
    const expense = {
      id: expenses.length+1,
      name,
      justification,
      receiptUrl: "https://example.com/receipts/expense2",
      quantity,
      unitPrice,
      totalPrice,
      date: new Date("2023-02-05"),
      userId: 102,
      expenseTypeId: 1
    }
    storeHandleExpense(expense)
    navigation.navigate('IndexExpensesScreen')
  }

  return (
    <>
    <View style={styles.container}>
      <TextInput
        placeholder='Cantidad*'
        keyboardType='numeric'
        autoCapitalize='none'
        value={quantity}
        onChangeText={(quantity) => {setCount(quantity)}}
        returnKeyType="next"
      />
      <TextInput
        placeholder='Gasto*'
        keyboardType='text'
        autoCapitalize='none'
        value={name}
        onChangeText={(name) => setName(name)}
        returnKeyType="next"
      />
      <TextInput
        placeholder='Valor Unidad*'
        keyboardType='numeric'
        autoCapitalize='none'
        value={unitPrice}
        onChangeText={(unitPrice) => setUnitPrice(unitPrice)}
        returnKeyType="next"
      />
      <TextInput
        placeholder='Justificacion del Gasto*'
        keyboardType='text'
        autoCapitalize='none'
        value={justification}
        onChangeText={(justification) => setJustification(justification)}
        returnKeyType="next"
      />
      <TextInput
        placeholder='Valor Total*'
        keyboardType='numeric'
        autoCapitalize='none'
        value={totalPrice}
        onChangeText={(totalPrice) => setTotalPrice(totalPrice)}
      />
      <TouchableOpacity style={styles.loginButton} onPress={() => onRegister() }>
        <Text style={styles.loginButtonText}>Registrar Gasto</Text>
      </TouchableOpacity>
    </View>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'flex-start',
    alignItems: 'center',
    padding: 20,
    backgroundColor:'white',
  },
  flag: {
    backgroundColor: 'white',
    padding:5,
    width: '100%',
    marginBottom: 5,
    borderRadius: 14,
    height: 70,
    justifyContent: 'center',
    paddingLeft: 9,
  },
  containerExpense: {
    display: 'flex',
    flexDirection: 'row',
  },
  expense: {
    color: '#4b5563',
    fontSize: 18,
    fontWeight: 'bold',
    width:'70%',
  },
  price: {
    color: gray[700],
    fontSize: 18,
    fontWeight: 'bold',
    width:'30%',
    textAlign: 'right',
  },
  loginButton: {
    backgroundColor: 'black',
    padding: 10,
    borderRadius: 5,
    width: '100%',
    height: 50,
    marginTop: 12,
    justifyContent: 'center', // Centrado vertical
    alignItems: 'center', // Centrado horizontal
  },
  loginButtonText: {
    color: 'white',
    textAlign: 'center',
    fontWeight: 'bold',
  },
});

export default CreateExpenseScreen;
