import { configureStore, combineReducers } from '@reduxjs/toolkit';

import userReducer from './users/slice';
import userAuthReducer from './auth/slice';

import expenseReducer from './expenses/slice';

// const persistanceLocalStorageMiddleware = (store) => (next) => (action) => {
//     next(action)
// } 

export const store = configureStore({
  reducer: {
    users: userReducer,
    userAuth: userAuthReducer,
    expenses: expenseReducer,
  },
  // middleware: [persistanceLocalStorageMiddleware]
})

export type RootState = ReturnType<typeof store.getState>
export type AppDispatch = typeof store.dispatch
