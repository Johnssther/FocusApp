import { createSlice, type PayloadAction } from "@reduxjs/toolkit";

type UserId = string 

export interface User {
  name: string,
  email: string,
  github: string,
}

export interface UserWithId extends User {
  id: string,
}

const initialState: UserWithId[] = [
    {
      id: 'f2o58yvpt854iyltf3r3545',
      name: 'John Alejandro',
      email: 'john@gmail.com',
      github: 'john',
    },
    {
      id: 'do34ur38043orh34bf9248of',
      name: 'Stefania',
      email: 'stefania@gmail.com',
      github: 'stefania11',
    },
    {
      id: 'uniqueID',
      name: 'Nuevo Usuario',
      email: 'nuevo@gmail.com',
      github: 'nuevo',
    },
]

export const userSlice = createSlice({
  name: 'users',
  initialState,
  reducers: {

    /* Store User */
    storeUser: (state, action) => {

    },

    /* Update User */
    updateUser: (state, action) => {

    },

    /* Show User */
    showUser: (state, action) => {

    },

    /* Destroy User */
    destroyUser: (state, action) => {

    },

    /* Delete User By Id */
    deleteUserById: (state, action: PayloadAction<UserId>) => {
      const id = action.payload;
      return state.filter((user) => user.id != id);
    }
  }
});

export default userSlice.reducer;

export const { storeUser, updateUser, showUser, destroyUser, deleteUserById } =  userSlice.actions;
