import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  input: {
    width: '100%',
    height: 50,
    borderColor: 'gray',
    borderWidth: 1,
    borderRadius: 30,
    marginBottom: 20,
    padding: 10,
    fontSize: 14,
    textAlign: 'center'
  },
});

export default styles;
