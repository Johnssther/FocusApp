import { StyleSheet } from 'react-native';

const styles = StyleSheet.create({
  input: {
    width: '100%',
    height: 50,
    borderColor: '#bcabab',
    borderWidth: 1,
    borderRadius: 5,
    marginBottom: 20,
    padding: 10,
    fontSize: 16,
    backgroundColor: 'white',
    fontWeight: 'bold',
    textTransform: 'capitalize',
  },
});

export default styles;
