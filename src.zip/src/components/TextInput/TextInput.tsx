import React from 'react';
import { TextInput as RNTextInput, StyleSheet, TextInputProps } from 'react-native';
import styles from './style';

interface Props extends TextInputProps {
  placeholder: string;
  secureTextEntry?: boolean;
  keyboardType?: 'default' | 'email-address' | 'numeric' | 'phone-pad';
  autoCapitalize?: 'none' | 'sentences' | 'words' | 'characters';
}

const TextInput: React.FC<Props> = ({ placeholder, secureTextEntry, keyboardType, autoCapitalize, ...props }) => (
  <RNTextInput
    style={styles.input}
    placeholder={placeholder}
    secureTextEntry={secureTextEntry}
    keyboardType={keyboardType}
    autoCapitalize={autoCapitalize}
    {...props}
  />
);



export default TextInput;
